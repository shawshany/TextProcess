#!/usr/bin/python3
# -*-coding:utf-8 -*-
#Reference:**********************************************
# @Time     : 2019-09-30 12:34
# @Author   : 病虎
# @E-mail   : victor.xsyang@gmail.com
# @File     : __init__.py
# @User     : ora
# @Software: PyCharm
# @Description: 
#Reference:**********************************************
name = "TextProcess"
